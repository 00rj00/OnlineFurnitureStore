package com.service;

import java.sql.Date;
import java.util.Calendar;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service;
import com.entity.*;
import com.exception.ReportException;
//import com.exception.*;
import com.repository.*;

@Service
@Transactional
public class PaymentServices implements PaymentService
{
	@Autowired
	BillRepository br;
	
	@Autowired
	OrderRepository or;
	
	@Autowired
	CustomerRepository cr;

	@Override
	public Bill getBillById(long billNo) 
	{
		return br.findById(billNo).orElse(null);
	}

	@Override
	public double payByCash(double amount) throws Exception {
		String username = "Harshith";
		String email = "harshith@gmail.com";
		Customer customer = cr.findByEmail(email);
		Bill bill = br.findByCustomer(username);
		double change = bill.getAmount() - amount;
		try 
		{
			if (change == 0 || change < 0) 
			{
				FurnitureOrder order = new FurnitureOrder(UUID.randomUUID().toString(), new Date(0), bill.getFurniture(), customer,
						bill.getQuanity(), bill.getPrice(), bill.getAmount(), "paid");
				or.save(order);
			} 
			else 
			{
				throw new Exception("You need to pay: " + bill.getAmount());
			}
		} 
		catch (Exception e) 
		{
			throw e;
		}
		return change;
	}

	@Override
	public Card payByCard(Card card) throws Exception
	{
		String username = "Harshith";
		String email = "harshith@gmail.com";
		Customer customer = cr.findByEmail(email);
		Bill bill = br.findByCustomer(username);
		if (isCardValid(card)) {
			FurnitureOrder order = new FurnitureOrder(UUID.randomUUID().toString(), new Date(0), bill.getFurniture(), customer,
					bill.getQuanity(), bill.getPrice(), bill.getAmount(), "paid");
			or.save(order);
		}
		card.setCardNumber("XXXXXX"+card.getCardNumber().substring(card.getCardNumber().length()-3));
		return card;
	}
	
	private boolean isCardValid(Card card) throws Exception
	{
		if(!(card.getCardNumber().equals(null)) && (card.getCvv()!=0)) 
		{
			if (card.getCvv() > 3) 
			{
				throw new ReportException("Invalid CVV");
			}
			if (card.getCardNumber().length() > 9) 
			{
				throw new ReportException("Invalid card number");
			}
			if (null == card.getCardExpiry()) 
			{
				throw new ReportException("Card expirty date is invalid. Cause: ExpiryDate object is null");
			} 
			else 
			{
				if(card.getCardExpiry().getYear()!=0 && card.getCardExpiry().getDayOfMonth()!=0) 
				{
					if(card.getCardExpiry().getYear() < Calendar.YEAR)
					{
						throw new ReportException("Card expirty date is invalid. Cause: Expiry year is invalid");
					}
					if((card.getCardExpiry().getDayOfMonth())> 12 || (card.getCardExpiry().getDayOfMonth()) < 0)
					{
						throw new ReportException("Card expirty date is invalid. Cause: Expiry month is invalid");
					}
				}
			}
			return true;
		} 
		else 
		{
			return false;
		}
	}

}
