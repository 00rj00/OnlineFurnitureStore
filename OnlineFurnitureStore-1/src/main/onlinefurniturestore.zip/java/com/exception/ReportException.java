package com.exception;

@SuppressWarnings("serial")
public class ReportException extends Exception {

	public ReportException(String msg) {
		super(msg);
	}
}
