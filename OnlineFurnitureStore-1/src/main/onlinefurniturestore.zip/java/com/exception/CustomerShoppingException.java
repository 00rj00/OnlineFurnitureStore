package com.exception;

@SuppressWarnings("serial")
public class CustomerShoppingException extends Exception {

	public CustomerShoppingException(String str) {
		super(str);
	}
}
