package com.exception;

@SuppressWarnings("serial")
public class CustomerFeedbackException extends Exception {

	public CustomerFeedbackException(String str) {
		super(str);
	}
}
