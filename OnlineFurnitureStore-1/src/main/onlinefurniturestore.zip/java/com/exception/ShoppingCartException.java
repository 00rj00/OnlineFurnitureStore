package com.exception;

@SuppressWarnings("serial")
public class ShoppingCartException extends Exception {

	public ShoppingCartException(String msg) {
		super(msg);
	}

}
