package com.exception;

@SuppressWarnings("serial")
public class FurnitureServiceException extends Exception {

	public FurnitureServiceException(String str) {
		super(str);
	}
}
